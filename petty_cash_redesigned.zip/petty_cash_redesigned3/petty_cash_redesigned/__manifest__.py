{
    'name': 'Petty Cash Management - Redesigned',
    'version': '17.0.3.1.0',
    'category': 'Accounting',
    'summary': 'Manage petty cash with reimbursement and advance flows using vendor bills',
    'description': """
        Petty Cash Management Module - Redesigned
        ==========================================
        
        Key Features:
        -------------
        * Two Workflow Types:
          - Reimbursement Flow: Employee pays from pocket → submits bills → gets reimbursed
          - Advance Flow: Employee requests advance → receives cash → submits bills for settlement
        
        * Bill-Based Accounting:
          - Creates vendor bills (account.move) instead of journal entries
          - Employees are treated as vendors
          - Easy reconciliation for accountants
        
        * Automatic Requester:
          - Requester is always the logged-in user
          - No option to select different requester
        
        * Two-Level Validation:
          - Request approval (manager/custodian)
          - Bill validation (accountant)
        
        * Smart Bill Line Management:
          - Multiple expense lines per request
          - Category-based expense accounts
          - Attachment support for receipts
    """,
    'author': 'GST International',
    'website': 'https://gstsaudi.com/odoo-apps/petty-cash-management',
    'depends': ['base', 'account', 'mail'],
 'data': [
        'security/petty_cash_security.xml', # 1. Define groups and rules
        'security/ir.model.access.csv',    # 2. Grant permissions to those groups
        'data/petty_cash_sequence.xml',
        'wizard/petty_cash_reject_wizard_views.xml',
        'wizard/petty_cash_settlement_wizard_views.xml',
        'views/petty_cash_expense_category_views.xml',
        'views/petty_cash_request_views.xml',
        'views/petty_cash_fund_views.xml',
        'views/petty_cash_menus.xml',      # 3. Menus use the groups defined in step 1
        'report/petty_cash_reports.xml',
        'report/petty_cash_report_templates.xml',
    ],
    'demo': [],
    'installable': True,
    'application': True,
    'auto_install': False,
    'license': 'LGPL-3',
}
