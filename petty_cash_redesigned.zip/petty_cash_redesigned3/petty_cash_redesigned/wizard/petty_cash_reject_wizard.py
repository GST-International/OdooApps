from odoo import models, fields, api, _


class PettyCashRejectWizard(models.TransientModel):
    _name = 'petty.cash.reject.wizard'
    _description = 'Petty Cash Request Rejection Wizard'

    request_id = fields.Many2one(
        'petty.cash.request',
        string='Request',
        required=True
    )
    reason = fields.Text(string='Rejection Reason', required=True)

    def action_reject(self):
        self.ensure_one()
        self.request_id.write({
            'state': 'rejected',
            'rejection_reason': self.reason
        })
        return {'type': 'ir.actions.act_window_close'}
