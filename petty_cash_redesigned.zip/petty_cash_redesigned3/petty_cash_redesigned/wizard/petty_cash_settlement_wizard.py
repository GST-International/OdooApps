from odoo import models, fields, api, _
from odoo.exceptions import UserError


class PettyCashSettlementWizard(models.TransientModel):
    _name = 'petty.cash.settlement.wizard'
    _description = 'Petty Cash Settlement Wizard'

    request_id = fields.Many2one(
        'petty.cash.request',
        string='Request',
        required=True
    )
    amount_requested = fields.Monetary(
        related='request_id.amount_requested',
        string='Amount Requested',
        readonly=True
    )
    amount_settled = fields.Monetary(
        related='request_id.amount_settled',
        string='Amount Spent',
        readonly=True
    )
    amount_difference = fields.Monetary(
        related='request_id.amount_difference',
        string='Difference',
        readonly=True
    )
    currency_id = fields.Many2one(
        'res.currency',
        related='request_id.currency_id'
    )
    
    notes = fields.Text(string='Settlement Notes')
    
    settlement_type = fields.Selection([
        ('return', 'Employee Returns Unused Amount'),
        ('reimburse', 'Additional Reimbursement Needed'),
        ('exact', 'Exact Amount Spent')
    ], string='Settlement Type', compute='_compute_settlement_type')
    
    @api.depends('amount_difference')
    def _compute_settlement_type(self):
        for wizard in self:
            if wizard.amount_difference > 0:
                wizard.settlement_type = 'return'
            elif wizard.amount_difference < 0:
                wizard.settlement_type = 'reimburse'
            else:
                wizard.settlement_type = 'exact'
    
    def action_settle(self):
        self.ensure_one()
        
        # Validate all bills are properly entered
        if not self.request_id.expense_line_ids:
            raise UserError(_('No expense lines found. Please add all expenses before settling.'))
        
        # Perform settlement
        self.request_id.action_settle()
        
        return {'type': 'ir.actions.act_window_close'}
