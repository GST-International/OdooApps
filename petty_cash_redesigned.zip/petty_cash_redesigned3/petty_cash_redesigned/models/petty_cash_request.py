from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError


class PettyCashRequest(models.Model):
    _name = 'petty.cash.request'
    _description = 'Petty Cash Request'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'date desc, id desc'

    name = fields.Char(
        string='Reference', 
        required=True, 
        copy=False, 
        readonly=True, 
        default=lambda self: _('New')
    )
    fund_id = fields.Many2one(
        'petty.cash.fund', 
        string='Petty Cash Fund', 
        required=True, 
        tracking=True,
        domain="[('state', '=', 'active')]"
    )
    date = fields.Date(
        string='Request Date', 
        required=True, 
        default=fields.Date.context_today, 
        tracking=True
    )
    
    # CRITICAL CHANGE: Requester is always current user, readonly, no selection
    requester_id = fields.Many2one(
        'res.users', 
        string='Requester', 
        required=True, 
        default=lambda self: self.env.user,
        readonly=True,  # Cannot be changed
        tracking=True
    )
    
    # Vendor selection - can be different from requester (on behalf of vendor)
    vendor_id = fields.Many2one(
        'res.partner',
        string='Vendor',
        required=True,
        tracking=True,
        domain="[('supplier_rank', '>', 0)]",
        help='Select the vendor for this request. Requester may submit on behalf of a vendor.'
    )
    
    # Link to partner (vendor) for bill creation - now computed from vendor_id
    partner_id = fields.Many2one(
        'res.partner',
        string='Bill Partner',
        compute='_compute_partner_id',
        store=True,
        help='The partner used for bill creation (same as vendor)'
    )
    
    currency_id = fields.Many2one(
        'res.currency', 
        related='fund_id.currency_id', 
        readonly=True
    )
    company_id = fields.Many2one(
        'res.company',
        related='fund_id.company_id',
        store=True
    )
    
    # Request Type - Key differentiator for the two flows
    request_type = fields.Selection([
        ('reimbursement', 'Reimbursement (Pay from Pocket)'),
        ('advance', 'Advance (Request Money First)')
    ], string='Request Type', required=True, default='reimbursement', tracking=True,
       help="""
       Reimbursement: You paid from your own pocket and want to be reimbursed.
       Advance: You need money in advance, will spend it and provide bills later.
       """)
    
    # Amounts
    amount_requested = fields.Monetary(
        string='Amount Requested', 
        required=True, 
        tracking=True,
        help='For Reimbursement: Total of your expense bills. For Advance: Amount you need.'
    )
    amount_settled = fields.Monetary(
        string='Amount Settled',
        compute='_compute_amount_settled',
        store=True,
        help='Actual amount spent (from bills)'
    )
    amount_difference = fields.Monetary(
        string='Difference',
        compute='_compute_amount_settled',
        store=True,
        help='Difference between requested and settled. Positive = return to fund, Negative = additional reimbursement'
    )
    
    purpose = fields.Text(string='Purpose', required=True)
    
    # Enhanced State Flow
    state = fields.Selection([
        ('draft', 'Draft'),
        ('submitted', 'Submitted'),
        ('approved', 'Approved'),
        ('disbursed', 'Disbursed'),  # Only for Advance flow
        ('submitted_bills', 'Bills Submitted'),  # After expenses are recorded
        ('settled', 'Settled'),  # Final state - bills validated
        ('rejected', 'Rejected'),
        ('cancelled', 'Cancelled')
    ], string='Status', default='draft', tracking=True)
    
    # Approval tracking
    approved_by = fields.Many2one('res.users', string='Approved By', readonly=True, tracking=True)
    approval_date = fields.Datetime(string='Approval Date', readonly=True)
    disbursed_by = fields.Many2one('res.users', string='Disbursed By', readonly=True, tracking=True)
    disbursement_date = fields.Datetime(string='Disbursement Date', readonly=True)
    settled_by = fields.Many2one('res.users', string='Settled By', readonly=True, tracking=True)
    settlement_date = fields.Datetime(string='Settlement Date', readonly=True)
    
    rejection_reason = fields.Text(string='Rejection Reason')
    
    # Expense Lines - Multiple expenses per request
    expense_line_ids = fields.One2many(
        'petty.cash.request.line',
        'request_id',
        string='Expense Lines'
    )
    
    # Bills created for this request
    bill_ids = fields.One2many(
        'account.move',
        'petty_cash_request_id',
        string='Bills',
        domain="[('move_type', '=', 'in_invoice')]"
    )
    bill_count = fields.Integer(compute='_compute_bill_count', string='Bill Count')
    
    # Disbursement move (for advance flow)
    disbursement_move_id = fields.Many2one(
        'account.move',
        string='Disbursement Entry',
        readonly=True,
        copy=False
    )
    
    # Settlement move (for returns or additional payments)
    settlement_move_id = fields.Many2one(
        'account.move',
        string='Settlement Entry',
        readonly=True,
        copy=False
    )
    
    # Attachments for receipts
    attachment_ids = fields.Many2many(
        'ir.attachment',
        'petty_cash_request_attachment_rel',
        'request_id',
        'attachment_id',
        string='Attachments/Receipts'
    )
    
    @api.depends('vendor_id')
    def _compute_partner_id(self):
        """Get the partner from selected vendor"""
        for request in self:
            request.partner_id = request.vendor_id
    
    @api.depends('expense_line_ids.subtotal', 'bill_ids.state', 'bill_ids.amount_total')
    def _compute_amount_settled(self):
        for request in self:
            # Calculate from expense lines
            request.amount_settled = sum(request.expense_line_ids.mapped('subtotal'))
            request.amount_difference = request.amount_requested - request.amount_settled
    
    @api.depends('bill_ids')
    def _compute_bill_count(self):
        for request in self:
            request.bill_count = len(request.bill_ids)
    
    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get('name', _('New')) == _('New'):
                vals['name'] = self.env['ir.sequence'].next_by_code('petty.cash.request') or _('New')
            # Ensure requester is always current user
            vals['requester_id'] = self.env.user.id
        return super().create(vals_list)
    
    def write(self, vals):
        # Prevent changing requester
        if 'requester_id' in vals:
            # Only allow during system operations
            if not self._context.get('install_mode') and not self._context.get('force_requester'):
                vals.pop('requester_id', None)
        return super().write(vals)
    
    @api.constrains('amount_requested')
    def _check_amount(self):
        for request in self:
            if request.amount_requested <= 0:
                raise ValidationError(_('Amount requested must be greater than zero.'))
    
    @api.constrains('vendor_id', 'request_type')
    def _check_vendor_unsettled_advance(self):
        """Check if vendor has unsettled advance requests"""
        for request in self:
            if request.request_type == 'advance' and request.vendor_id:
                unsettled = self.search([
                    ('vendor_id', '=', request.vendor_id.id),
                    ('request_type', '=', 'advance'),
                    ('state', 'in', ['approved', 'disbursed', 'submitted_bills']),
                    ('id', '!=', request.id if request.id else 0)
                ], limit=1)
                if unsettled:
                    raise ValidationError(_(
                        'Vendor "%s" has an unsettled advance request (%s). '
                        'Please settle it before creating a new advance request for this vendor.'
                    ) % (request.vendor_id.name, unsettled.name))
    
    @api.onchange('expense_line_ids')
    def _onchange_expense_lines(self):
        """Auto-update amount for reimbursement requests"""
        if self.request_type == 'reimbursement' and self.expense_line_ids:
            self.amount_requested = sum(self.expense_line_ids.mapped('subtotal'))
    
    # ==================== WORKFLOW ACTIONS ====================
    
    def action_submit(self):
        """Submit request for approval"""
        for request in self:
            if request.request_type == 'reimbursement' and not request.expense_line_ids:
                raise UserError(_('Please add expense lines with your bills before submitting a reimbursement request.'))
            request.write({'state': 'submitted'})
    
    def action_approve(self):
        """Approve the request"""
        for request in self:
            # Check fund balance for advance requests
            if request.request_type == 'advance':
                if request.amount_requested > request.fund_id.current_balance:
                    raise UserError(_(
                        'Insufficient funds. Current balance: %s %s'
                    ) % (request.fund_id.current_balance, request.currency_id.symbol))
            
            request.write({
                'state': 'approved',
                'approved_by': self.env.user.id,
                'approval_date': fields.Datetime.now()
            })
            
            # For reimbursement, create bill immediately after approval
            if request.request_type == 'reimbursement':
                request._create_expense_bill()
    
    def action_disburse(self):
        """Disburse cash for advance requests"""
        for request in self:
            if request.request_type != 'advance':
                raise UserError(_('Disbursement is only for advance requests.'))
            
            if request.state != 'approved':
                raise UserError(_('Only approved requests can be disbursed.'))
            
            # Create disbursement journal entry
            request._create_disbursement_entry()
            
            request.write({
                'state': 'disbursed',
                'disbursed_by': self.env.user.id,
                'disbursement_date': fields.Datetime.now()
            })
    
    def action_submit_bills(self):
        """Submit expense bills for advance requests after spending"""
        for request in self:
            if request.request_type != 'advance':
                raise UserError(_('This action is only for advance requests.'))
            
            if not request.expense_line_ids:
                raise UserError(_('Please add expense lines before submitting bills.'))
            
            # Create the expense bill
            request._create_expense_bill()
            
            request.write({'state': 'submitted_bills'})
    
    def action_settle(self):
        """Final settlement - validate bills and handle differences"""
        for request in self:
            # Create settlement entry if there's a difference (for advance flow)
            if request.request_type == 'advance' and request.amount_difference != 0:
                request._create_settlement_entry()
            
            request.write({
                'state': 'settled',
                'settled_by': self.env.user.id,
                'settlement_date': fields.Datetime.now()
            })
    
    def action_reject(self):
        """Open rejection wizard"""
        self.ensure_one()
        return {
            'name': _('Reject Request'),
            'type': 'ir.actions.act_window',
            'res_model': 'petty.cash.reject.wizard',
            'view_mode': 'form',
            'target': 'new',
            'context': {'default_request_id': self.id}
        }
    
    def action_cancel(self):
        """Cancel the request"""
        for request in self:
            # Cancel related bills if in draft
            for bill in request.bill_ids.filtered(lambda b: b.state == 'draft'):
                bill.button_cancel()
            
            # Reverse disbursement if applicable
            if request.disbursement_move_id and request.disbursement_move_id.state == 'posted':
                request.disbursement_move_id._reverse_moves()
            
            request.write({'state': 'cancelled'})
    
    def action_reset_to_draft(self):
        """Reset cancelled/rejected request to draft"""
        for request in self:
            if request.state not in ['rejected', 'cancelled']:
                raise UserError(_('Only rejected or cancelled requests can be reset to draft.'))
            request.write({
                'state': 'draft',
                'rejection_reason': False
            })
    
    def action_view_bills(self):
        """View related bills"""
        self.ensure_one()
        return {
            'name': _('Bills'),
            'type': 'ir.actions.act_window',
            'res_model': 'account.move',
            'view_mode': 'tree,form',
            'domain': [('id', 'in', self.bill_ids.ids)],
            'context': {'default_move_type': 'in_invoice'}
        }
    
    def action_open_settlement_wizard(self):
        """Open settlement wizard"""
        self.ensure_one()
        return {
            'name': _('Settle Request'),
            'type': 'ir.actions.act_window',
            'res_model': 'petty.cash.settlement.wizard',
            'view_mode': 'form',
            'target': 'new',
            'context': {'default_request_id': self.id}
        }
    
    # ==================== BILL/ENTRY CREATION METHODS ====================
    
    def _create_expense_bill(self):
        """Create vendor bill for expenses"""
        self.ensure_one()
        
        if not self.expense_line_ids:
            raise UserError(_('No expense lines to create bill from.'))
        
        if not self.partner_id:
            raise UserError(_('No vendor selected. Please select a vendor for this request.'))
        
        invoice_lines = []
        for line in self.expense_line_ids:
            if not line.category_id.account_id:
                raise UserError(_(
                    'Expense category "%s" does not have an expense account configured.'
                ) % line.category_id.name)
            
            # Build description with receipt number
            line_name = line.description or line.category_id.name
            if line.receipt_number:
                line_name = f"[{line.receipt_number}] {line_name}"
            
            line_vals = {
                'name': line_name,
                'account_id': line.category_id.account_id.id,
                'quantity': 1,
                'price_unit': line.amount,  # Use base amount, tax will be computed
            }
            
            # Add tax if specified
            if line.tax_id:
                line_vals['tax_ids'] = [(6, 0, [line.tax_id.id])]
            else:
                line_vals['tax_ids'] = [(5, 0, 0)]  # Clear taxes
            
            # Add analytic account if specified
            if line.job_analytic_account_id:
                line_vals['analytic_distribution'] = {str(line.job_analytic_account_id.id): 100}
            
            invoice_lines.append((0, 0, line_vals))
        
        bill_vals = {
            'move_type': 'in_invoice',
            'partner_id': self.partner_id.id,
            'invoice_date': fields.Date.today(),
            'date': fields.Date.today(),
            'journal_id': self.fund_id.bills_journal_id.id,
            'ref': f'{self.name} - Petty Cash {self.request_type.title()}',
            'petty_cash_request_id': self.id,
            'invoice_line_ids': invoice_lines,
        }
        
        # Set job_analytic_account on the bill header if all lines have the same one
        job_accounts = self.expense_line_ids.mapped('job_analytic_account_id')
        if len(job_accounts) == 1 and job_accounts:
            bill_vals['job_analytic_account'] = job_accounts.id
        
        bill = self.env['account.move'].create(bill_vals)
        
        # Copy attachments to the bill
        for attachment in self.attachment_ids:
            attachment.copy({
                'res_model': 'account.move',
                'res_id': bill.id,
            })
        
        return bill
    
    def _create_disbursement_entry(self):
        """Create journal entry for cash disbursement (Advance flow)"""
        self.ensure_one()
        
        fund = self.fund_id
        
        # Debit: Employee Advance (Receivable from Employee) - use partner's payable account
        # Credit: Cash/Bank (Petty Cash Account)
        move_vals = {
            'date': fields.Date.today(),
            'journal_id': fund.cash_journal_id.id,
            'ref': f'{self.name} - Petty Cash Advance Disbursement',
            'line_ids': [
                (0, 0, {
                    'name': f'Advance to {self.requester_id.name}',
                    'partner_id': self.partner_id.id,
                    'account_id': self.partner_id.property_account_payable_id.id,
                    'debit': self.amount_requested,
                    'credit': 0.0,
                }),
                (0, 0, {
                    'name': f'Cash disbursement for {self.name}',
                    'account_id': fund.account_id.id,
                    'debit': 0.0,
                    'credit': self.amount_requested,
                }),
            ]
        }
        
        move = self.env['account.move'].create(move_vals)
        move.action_post()
        self.disbursement_move_id = move.id
        
        return move
    
    def _create_settlement_entry(self):
        """Create settlement entry for difference in advance flow
        
        If employee spent less than advance:
        - Excess stays as credit in vendor's payable account (no cash entry)
        - This creates a liability that can be used for future transactions
        
        If employee spent more than advance:
        - Additional amount needs to be paid, create cash disbursement
        """
        self.ensure_one()
        
        if self.amount_difference == 0:
            return False
        
        fund = self.fund_id
        
        if self.amount_difference > 0:
            # Employee used less than advance - excess stays in vendor payable
            # No journal entry needed - the amount remains as credit balance
            # in vendor's account from the original disbursement
            # Just log the information
            self.message_post(
                body=_(
                    'Settlement completed. Unused amount of %s %s remains as credit '
                    'in vendor account for future use.'
                ) % (self.amount_difference, self.currency_id.symbol)
            )
            return False
        else:
            # Employee spent more - Additional reimbursement needed
            # Debit: Vendor Payable (increase liability)
            # Credit: Cash (pay additional amount)
            move_vals = {
                'date': fields.Date.today(),
                'journal_id': fund.cash_journal_id.id,
                'ref': f'{self.name} - Additional Reimbursement',
                'line_ids': [
                    (0, 0, {
                        'name': f'Additional reimbursement to {self.vendor_id.name}',
                        'partner_id': self.partner_id.id,
                        'account_id': self.partner_id.property_account_payable_id.id,
                        'debit': abs(self.amount_difference),
                        'credit': 0.0,
                    }),
                    (0, 0, {
                        'name': f'Cash disbursement for {self.name}',
                        'account_id': fund.account_id.id,
                        'debit': 0.0,
                        'credit': abs(self.amount_difference),
                    }),
                ]
            }
            
            move = self.env['account.move'].create(move_vals)
            move.action_post()
            self.settlement_move_id = move.id
            
            return move


class PettyCashRequestLine(models.Model):
    _name = 'petty.cash.request.line'
    _description = 'Petty Cash Request Line'
    _order = 'sequence, id'

    request_id = fields.Many2one(
        'petty.cash.request',
        string='Request',
        required=True,
        ondelete='cascade'
    )
    sequence = fields.Integer(string='Sequence', default=10)
    
    category_id = fields.Many2one(
        'petty.cash.expense.category',
        string='Category',
        required=True
    )
    description = fields.Char(string='Description')
    date = fields.Date(string='Expense Date', default=fields.Date.context_today)
    receipt_number = fields.Char(string='Receipt/Invoice No.')
    vendor_name = fields.Char(string='Vendor/Shop Name')
    
    # Job Analytic Account
    job_analytic_account_id = fields.Many2one(
        'account.analytic.account',
        string='Job Code',
        help='Select the job/project code for this expense'
    )
    
    # Amount fields with tax support
    amount = fields.Monetary(string='Amount', required=True, help='Amount before tax')
    tax_id = fields.Many2one(
        'account.tax',
        string='Tax',
        domain="[('type_tax_use', '=', 'purchase')]",
        help='Select tax if applicable'
    )
    tax_amount = fields.Monetary(string='Tax Amount', compute='_compute_amounts', store=True)
    subtotal = fields.Monetary(string='Total', compute='_compute_amounts', store=True, help='Amount including tax')
    
    currency_id = fields.Many2one(
        'res.currency',
        related='request_id.currency_id',
        readonly=True
    )
    
    attachment_ids = fields.Many2many(
        'ir.attachment',
        'petty_cash_line_attachment_rel',
        'line_id',
        'attachment_id',
        string='Receipt Attachment'
    )
    
    @api.depends('amount', 'tax_id')
    def _compute_amounts(self):
        for line in self:
            if line.tax_id and line.amount:
                taxes = line.tax_id.compute_all(line.amount, line.currency_id, 1)
                line.tax_amount = taxes['total_included'] - taxes['total_excluded']
                line.subtotal = taxes['total_included']
            else:
                line.tax_amount = 0.0
                line.subtotal = line.amount or 0.0
    
    @api.onchange('category_id')
    def _onchange_category(self):
        if self.category_id and not self.description:
            self.description = self.category_id.name


class AccountMove(models.Model):
    _inherit = 'account.move'
    
    petty_cash_request_id = fields.Many2one(
        'petty.cash.request',
        string='Petty Cash Request',
        readonly=True,
        copy=False
    )
