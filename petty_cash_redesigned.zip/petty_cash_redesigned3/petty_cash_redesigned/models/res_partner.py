from odoo import models, fields, api, _


class ResPartner(models.Model):
    _inherit = 'res.partner'
    
    is_petty_cash_user = fields.Boolean(
        string='Is Petty Cash User',
        default=False,
        help='Check this if this partner/employee can request petty cash'
    )
    
    petty_cash_request_ids = fields.One2many(
        'petty.cash.request',
        'partner_id',
        string='Petty Cash Requests'
    )
    
    petty_cash_request_count = fields.Integer(
        compute='_compute_petty_cash_request_count',
        string='Petty Cash Requests'
    )
    
    @api.depends('petty_cash_request_ids')
    def _compute_petty_cash_request_count(self):
        for partner in self:
            partner.petty_cash_request_count = len(partner.petty_cash_request_ids)
    
    def action_view_petty_cash_requests(self):
        self.ensure_one()
        return {
            'name': _('Petty Cash Requests'),
            'type': 'ir.actions.act_window',
            'res_model': 'petty.cash.request',
            'view_mode': 'tree,form',
            'domain': [('partner_id', '=', self.id)],
            'context': {'default_partner_id': self.id}
        }
