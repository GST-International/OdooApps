from odoo import models, fields, api, _


class PettyCashExpenseCategory(models.Model):
    _name = 'petty.cash.expense.category'
    _description = 'Petty Cash Expense Category'
    _order = 'name'

    name = fields.Char(string='Category Name', required=True)
    code = fields.Char(string='Code', required=True)
    description = fields.Text(string='Description')
    account_id = fields.Many2one(
        'account.account', 
        string='Expense Account', 
        required=False,  # Not required at creation, but needed when using the category
        domain="[('account_type', 'in', ['expense', 'expense_direct_cost'])]",
        help='Account to be used when posting expenses in this category. Must be set before using this category.'
    )
    active = fields.Boolean(string='Active', default=True)
    color = fields.Integer(string='Color')
    
    _sql_constraints = [
        ('code_uniq', 'unique(code)', 'Category code must be unique!'),
    ]
