from odoo import models, fields, api, _
from odoo.exceptions import UserError

class PettyCashFund(models.Model):
    _name = 'petty.cash.fund'
    _description = 'Petty Cash Fund'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Fund Name', required=True, tracking=True)
    code = fields.Char(string='Code', required=True, copy=False, tracking=True)
    custodian_id = fields.Many2one('res.users', string='Custodian', required=True, tracking=True)
    company_id = fields.Many2one('res.company', string='Company', required=True, default=lambda self: self.env.company)
    currency_id = fields.Many2one('res.currency', related='company_id.currency_id', string='Currency', readonly=True)
    
    initial_amount = fields.Monetary(string='Initial Amount', required=True, tracking=True)
    current_balance = fields.Monetary(string='Current Balance', compute='_compute_current_balance', store=True)
    maximum_amount = fields.Monetary(string='Maximum Fund Amount', required=True, tracking=True)
    minimum_balance = fields.Monetary(string='Minimum Balance for Alert', tracking=True)
    
    bills_journal_id = fields.Many2one('account.journal', string='Bills Journal', required=True)
    cash_journal_id = fields.Many2one('account.journal', string='Cash/Bank Journal', required=True)
    account_id = fields.Many2one('account.account', string='Petty Cash Account', required=True)
    
    state = fields.Selection([
        ('draft', 'Draft'),
        ('active', 'Active'),
        ('suspended', 'Suspended'),
        ('closed', 'Closed')
    ], string='Status', default='draft', tracking=True)
    
    request_ids = fields.One2many('petty.cash.request', 'fund_id', string='Requests')
    
    request_count = fields.Integer(compute='_compute_request_count', string='Requests')
    pending_request_count = fields.Integer(compute='_compute_request_count', string='Pending Requests')
    total_disbursed = fields.Monetary(compute='_compute_totals', string='Total Disbursed')
    total_settled = fields.Monetary(compute='_compute_totals', string='Total Settled')
    outstanding_advances = fields.Monetary(compute='_compute_totals', string='Outstanding Advances')
    
    notes = fields.Text(string='Notes')

    @api.depends('request_ids.state', 'request_ids.amount_requested', 'request_ids.amount_settled', 'initial_amount')
    def _compute_current_balance(self):
        for fund in self:
            balance = fund.initial_amount
            for req in fund.request_ids:
                if req.request_type == 'advance':
                    if req.state in ['disbursed', 'submitted_bills', 'settled']:
                        balance -= req.amount_requested
                    if req.state == 'settled':
                        balance += (req.amount_requested - req.amount_settled)
                elif req.request_type == 'reimbursement' and req.state == 'settled':
                    balance -= req.amount_settled
            fund.current_balance = balance

    @api.depends('request_ids')
    def _compute_request_count(self):
        for fund in self:
            fund.request_count = len(fund.request_ids)
            fund.pending_request_count = len(fund.request_ids.filtered(
                lambda r: r.state in ['submitted', 'approved', 'disbursed', 'submitted_bills']
            ))

    @api.depends('request_ids.state', 'request_ids.amount_requested', 'request_ids.amount_settled')
    def _compute_totals(self):
        for fund in self:
            advances = fund.request_ids.filtered(lambda r: r.request_type == 'advance')
            fund.total_disbursed = sum(r.amount_requested for r in advances if r.state in ['disbursed', 'submitted_bills', 'settled'])
            fund.total_settled = sum(r.amount_settled for r in fund.request_ids if r.state == 'settled')
            fund.outstanding_advances = sum(r.amount_requested for r in advances if r.state in ['disbursed', 'submitted_bills'])

    # Action methods (Activate, Suspend, etc.) remain as you wrote them...
    def action_activate(self): self.write({'state': 'active'})
    def action_suspend(self): self.write({'state': 'suspended'})
    def action_reopen(self): self.write({'state': 'active'})
    def action_close(self):
        if any(f.outstanding_advances > 0 for f in self):
            raise UserError(_('Cannot close fund with outstanding advances.'))
        self.write({'state': 'closed'})

    def action_view_requests(self):
        return {
            'name': _('Petty Cash Requests'),
            'type': 'ir.actions.act_window',
            'res_model': 'petty.cash.request',
            'view_mode': 'tree,form',
            'domain': [('fund_id', '=', self.id)],
        }

    def action_view_pending_requests(self):
        return {
            'name': _('Pending Requests'),
            'type': 'ir.actions.act_window',
            'res_model': 'petty.cash.request',
            'view_mode': 'tree,form',
            'domain': [('fund_id', '=', self.id), ('state', 'in', ['submitted', 'approved', 'disbursed', 'submitted_bills'])],
        }